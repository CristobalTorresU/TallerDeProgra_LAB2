Taller de Programación, Laboratorio 2: Minimum Spanning Tree
